# ![book](database.png) Database Object Explorer (DBOE)

`DBOE` facilitates the navigation of SQL-based database engines by leveraging metadata. 

Engines tested to date include Microsoft SQL Server and MySQL.

Use `remotes::install_github('delriaan/DBOE, subdir = "pkg")` to install.
