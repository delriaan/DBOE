---
toc-title: Table of contents
---

# ![db](database.png) Database Object Explorer (DBOE)

`DBOE` facilitates the navigation of SQL-based database engines by
leveraging metadata.

Engines tested to date include Microsoft SQL Server.

Use `remotes::install_github('delriaan/DBOE, subdir = "pkg")` to
install.
